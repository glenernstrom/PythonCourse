# A program to convert the Nernst equation in natural log form to
# log10 form given user-provided system temperature in Celsius.

# The Nernst equation is an important neurophysiology concept defining
# electrochemical equilibrium potentials for a given permeant ion.

# E = (R * T / z * F) * log(x), where R = molar gas constant, T = temperature in Kelvin,
# z = ion valence, F = Faraday's consant, and x is the cocentration gradient (more precisely
# the ion activity ratio) of the ions outside to inside the cell. E is the equilibrium
# potential in volts. log(x) is the natural log.

# This is the most general form of the Nernst equation. Many textbooks
# simplify the above equation to 58 * log10(x) where the T is 20 degrees Celsisus. And
# this form of the Nernst equation returns the equilibrium potential in millivolts.


# Glen Ernstrom
# 2026-07-15

# ** NOT WORKING YET **


# I did figure out how to pull the physical constants from scipy from online sources
# but the error persists even if I used the rounded values in the functions below.

# will need to import math to get access to Euler's number and log functions
# for base conversion

def kelvin_converter(x):
    '''Takes an integer as degrees ceslius and returns temp in Kelvin'''
    return x + 273.15


def gas_temp(x):
    return 8.3145 * (kelvin_converter(x))


def faraday_quotient(x):
    return gas_temp(x) / 96485


if __name__ == '__main__':
    
    celsius = float(input("What is the temperature of the system you are studying in"
                          " \N{DEGREE SIGN}C ? "))
    
    # My intention here is to show the step-wise progression of this conversion as if
    # I were doing it by hand
    
    kelvin = kelvin_converter(celsius)
    gas_temp_prod = gas_temp(kelvin)
    rt_f = faraday_quotient(gas_temp_prod)
    
    print(f"The temperature is equivalent to {kelvin:.2f} K.")
    print(f"The gas constant is 8.3145 Joules per mol \u22c5 Kelvin.")
    print(f"The gas constant times temperature in Kelvin is {gas_temp_prod:.3f}")
    print(f"Faraday's constant is 96485 Coulombs per mole.")
    print(f"RT/F = {rt_f}.") # This values is wrong! I'm not sure why. Suspect scope issue.
    
    # Ruled out some possible memory or rounding issue, I get the same miscalculation
    # whether or not I round R and F or use the full known precision of these physical constants
    
    # TODO: Once RT/F is fixed, switch bases by multiplying by (1 / math.log10(math.e)) then
    # multiply by 1000 to get Nernst constant in units of millivolts.
    
    
